Built for use on Heroku with the nginx buildpack.
https://github.com/Prajjwal/nginx-buildpack-heroku.git
